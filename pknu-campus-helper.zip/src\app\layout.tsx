import type { Metadata } from "next";

import { AuthProvider } from "../components/auth/AuthProvider";
import { AppNavigation } from "../components/layout/AppNavigation";
import "./globals.css";

export const metadata: Metadata = {
  title: "PKNU 생활도우미",
  description: "부경대학교 대연캠퍼스 시설과 빈 강의실 정보",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ko">
      <body>
        <AuthProvider>
          <AppNavigation />
          <div className="pb-16 md:pb-0">{children}</div>
        </AuthProvider>
      </body>
    </html>
  );
}
