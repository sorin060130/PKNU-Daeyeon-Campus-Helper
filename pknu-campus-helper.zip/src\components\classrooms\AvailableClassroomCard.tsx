"use client";

import { useState } from "react";

import {
  endRoomUsage,
  startRoomUsage,
  type RoomUsage,
} from "../../services/roomUsageService";

export type AvailableClassroom = {
  id: string;
  name: string;
  building: string;
  nextClassStart: string | null;
};

type AvailableClassroomCardProps = {
  classroom: AvailableClassroom;
  roomUsage?: RoomUsage;
  sessionId: string;
};

export function AvailableClassroomCard({
  classroom,
  roomUsage,
  sessionId,
}: AvailableClassroomCardProps) {
  const [isUpdating, setIsUpdating] = useState(false);
  const [actionError, setActionError] = useState("");
  const isUsedByMe = roomUsage?.sessionId === sessionId;
  const isUsedByOther = Boolean(roomUsage && !isUsedByMe);

  async function handleStartUsage() {
    setIsUpdating(true);
    setActionError("");

    try {
      const started = await startRoomUsage(classroom.id, sessionId);

      if (!started) {
        setActionError("다른 사용자가 먼저 이용을 시작했습니다.");
      }
    } catch (error) {
      console.error("Failed to start room usage:", error);
      setActionError("이용 시작 상태를 저장하지 못했습니다.");
    } finally {
      setIsUpdating(false);
    }
  }

  async function handleEndUsage() {
    setIsUpdating(true);
    setActionError("");

    try {
      const ended = await endRoomUsage(classroom.id, sessionId);

      if (ended) {
        window.alert("에어컨/히터와 전등을 꺼주세요.");
      } else {
        setActionError("이용 종료 상태를 저장하지 못했습니다.");
      }
    } catch (error) {
      console.error("Failed to end room usage:", error);
      setActionError("이용 종료 상태를 저장하지 못했습니다.");
    } finally {
      setIsUpdating(false);
    }
  }

  return (
    <article
      className={`border bg-white p-5 shadow-sm ${
        isUsedByOther ? "border-amber-200" : "border-emerald-200"
      }`}
    >
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <p
            className={`mb-2 text-sm font-semibold ${
              isUsedByOther ? "text-amber-700" : "text-emerald-700"
            }`}
          >
            {isUsedByMe
              ? "내가 이용 중"
              : isUsedByOther
                ? "이용 상태 확인 필요"
                : "현재 사용 가능"}
          </p>
          <h2 className="truncate text-lg font-bold text-slate-950">{classroom.name}</h2>
          <p className="mt-1 truncate text-sm text-slate-600">{classroom.building}</p>
        </div>
        <span
          aria-hidden="true"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-lg font-bold text-emerald-700"
        >
          {classroom.name.charAt(0) || "강"}
        </span>
      </div>

      <div className="mt-5 border-t border-slate-100 pt-4">
        <p className="text-xs font-semibold text-slate-500">다음 수업 시작 시간</p>
        <p className="mt-1 text-base font-bold text-slate-900">
          {classroom.nextClassStart ?? "오늘 예정 없음"}
        </p>
      </div>

      {isUsedByOther && (
        <p className="mt-4 bg-amber-50 px-3 py-3 text-sm font-medium text-amber-800">
          현재 다른 사용자가 이용 중일 수 있습니다.
        </p>
      )}

      {actionError && (
        <p role="alert" className="mt-3 text-sm font-medium text-red-700">
          {actionError}
        </p>
      )}

      <button
        type="button"
        disabled={isUpdating || isUsedByOther || !sessionId}
        onClick={isUsedByMe ? handleEndUsage : handleStartUsage}
        className={`mt-4 h-11 w-full px-4 text-sm font-bold text-white transition disabled:cursor-not-allowed disabled:bg-slate-300 ${
          isUsedByMe
            ? "bg-slate-800 hover:bg-slate-700"
            : "bg-emerald-700 hover:bg-emerald-800"
        }`}
      >
        {isUpdating
          ? "처리 중..."
          : isUsedByMe
            ? "사용 종료"
            : isUsedByOther
              ? "다른 사용자 이용 중"
              : "강의실 이용 시작"}
      </button>
    </article>
  );
}
