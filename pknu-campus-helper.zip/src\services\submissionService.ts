import {
  get,
  onValue,
  push,
  ref,
  set,
  update,
  type Unsubscribe,
} from "firebase/database";

import { database } from "../lib/firebase";
import type { Weekday } from "./scheduleService";

export type ScheduleSubmissionInput = {
  classroomName: string;
  day: Weekday;
  startTime: string;
  endTime: string;
  reason: string;
};

export type ScheduleSubmission = ScheduleSubmissionInput & {
  id: string;
  status: "pending" | "approved" | "rejected";
  createdAt: number;
  reviewedAt?: number;
};

export async function createScheduleSubmission(
  input: ScheduleSubmissionInput,
): Promise<string> {
  const submissionRef = push(ref(database, "submissions"));

  const submission: Omit<ScheduleSubmission, "id"> = {
    ...input,
    status: "pending",
    createdAt: Date.now(),
  };

  await set(submissionRef, submission);

  if (!submissionRef.key) {
    throw new Error("Firebase did not generate a submission ID.");
  }

  return submissionRef.key;
}

export function subscribeToSubmissions(
  onChange: (submissions: ScheduleSubmission[]) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  return onValue(
    ref(database, "submissions"),
    (snapshot) => {
      if (!snapshot.exists()) {
        onChange([]);
        return;
      }

      const records = snapshot.val() as Record<string, Omit<ScheduleSubmission, "id">>;
      onChange(
        Object.entries(records)
          .map(([id, submission]) => ({ id, ...submission }))
          .sort((a, b) => b.createdAt - a.createdAt),
      );
    },
    onError,
  );
}

export async function approveSubmission(submission: ScheduleSubmission): Promise<void> {
  const schedulesSnapshot = await get(ref(database, "schedules"));
  const schedules = schedulesSnapshot.exists()
    ? (schedulesSnapshot.val() as Record<string, Record<string, unknown>>)
    : {};
  const matchingSchedule = Object.entries(schedules).find(([, schedule]) => {
    return schedule.classroomName === submission.classroomName && schedule.day === submission.day;
  });
  const scheduleId = matchingSchedule?.[0] ?? push(ref(database, "schedules")).key;

  if (!scheduleId) {
    throw new Error("Firebase did not generate a schedule ID.");
  }

  const updates: Record<string, unknown> = {
    [`schedules/${scheduleId}/classroomName`]: submission.classroomName,
    [`schedules/${scheduleId}/classroomId`]:
      matchingSchedule?.[1].classroomId ?? submission.classroomName,
    [`schedules/${scheduleId}/building`]: matchingSchedule?.[1].building ?? "미등록",
    [`schedules/${scheduleId}/day`]: submission.day,
    [`schedules/${scheduleId}/startTime`]: submission.startTime,
    [`schedules/${scheduleId}/endTime`]: submission.endTime,
    [`submissions/${submission.id}/status`]: "approved",
    [`submissions/${submission.id}/reviewedAt`]: Date.now(),
  };

  await update(ref(database), updates);
}

export async function rejectSubmission(submissionId: string): Promise<void> {
  await update(ref(database, `submissions/${submissionId}`), {
    status: "rejected",
    reviewedAt: Date.now(),
  });
}
