import { ArrowRight, Building2, CalendarClock, ClipboardPenLine } from "lucide-react";
import Link from "next/link";

const quickLinks = [
  {
    href: "/facilities",
    label: "시설 조회",
    description: "편의시설 위치와 운영시간",
    icon: Building2,
    color: "bg-sky-50 text-sky-700",
  },
  {
    href: "/classrooms",
    label: "빈 강의실",
    description: "지금 사용할 수 있는 강의실",
    icon: CalendarClock,
    color: "bg-emerald-50 text-emerald-700",
  },
  {
    href: "/edit-request",
    label: "시간표 수정 신청",
    description: "잘못된 강의 시간 제보",
    icon: ClipboardPenLine,
    color: "bg-amber-50 text-amber-700",
  },
];

export default function HomePage() {
  return (
    <main className="page-shell">
      <div className="content-wrap">
        <section className="border-b border-slate-200 pb-7 pt-2">
          <p className="eyebrow">부경대학교 대연캠퍼스</p>
          <h1 className="max-w-xl text-3xl font-extrabold text-slate-950 sm:text-4xl">
            오늘 캠퍼스 생활에 필요한 정보를 빠르게 확인하세요.
          </h1>
          <p className="mt-3 max-w-xl text-sm leading-6 text-slate-600">
            시설 운영시간부터 지금 비어 있는 강의실까지 한곳에서 확인할 수 있습니다.
          </p>
        </section>

        <section className="py-7" aria-labelledby="quick-menu-title">
          <div className="mb-4 flex items-center justify-between">
            <h2 id="quick-menu-title" className="text-lg font-bold text-slate-950">
              빠른 메뉴
            </h2>
            <span className="text-xs font-medium text-slate-500">대연캠퍼스 기준</span>
          </div>
          <div className="grid gap-4 sm:grid-cols-2">
            {quickLinks.map(({ href, label, description, icon: Icon, color }) => (
              <Link key={href} href={href} className="card group flex items-center gap-4 p-5">
                <span className={`flex h-12 w-12 shrink-0 items-center justify-center ${color}`}>
                  <Icon size={23} aria-hidden="true" />
                </span>
                <span className="min-w-0">
                  <strong className="block text-base text-slate-950">{label}</strong>
                  <span className="mt-1 block truncate text-sm text-slate-500">{description}</span>
                </span>
                <ArrowRight
                  size={18}
                  className="ml-auto shrink-0 text-slate-400 transition group-hover:translate-x-1 group-hover:text-sky-700"
                  aria-hidden="true"
                />
              </Link>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
