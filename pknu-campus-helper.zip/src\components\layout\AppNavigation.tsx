"use client";

import {
  Building2,
  CalendarClock,
  ClipboardPenLine,
  Heart,
  Home,
  LogIn,
  LogOut,
  ShieldCheck,
} from "lucide-react";
import Link from "next/link";
import { usePathname } from "next/navigation";

import { useAuth } from "../auth/AuthProvider";

const primaryLinks = [
  { href: "/", label: "홈", icon: Home },
  { href: "/facilities", label: "시설 조회", icon: Building2 },
  { href: "/classrooms", label: "빈 강의실", icon: CalendarClock },
  { href: "/edit-request", label: "수정 신청", icon: ClipboardPenLine },
  { href: "/favorites", label: "즐겨찾기", icon: Heart },
];

function isActive(pathname: string, href: string) {
  return href === "/" ? pathname === "/" : pathname.startsWith(href);
}

export function AppNavigation() {
  const pathname = usePathname();
  const { user, isLoading, isAdmin, login, logout } = useAuth();

  async function handleAuthAction() {
    try {
      if (user) {
        await logout();
      } else {
        await login();
      }
    } catch (error) {
      console.error("Authentication failed:", error);
      window.alert("로그인 처리 중 문제가 발생했습니다. 다시 시도해 주세요.");
    }
  }

  return (
    <>
      <header className="sticky top-0 z-40 flex h-14 items-center border-b border-slate-200 bg-white px-4 md:hidden">
        <Link href="/" className="font-extrabold text-slate-950">
          PKNU 생활도우미
        </Link>
        {isAdmin && (
          <Link
            href="/admin"
            title="관리자 페이지"
            className={`ml-auto flex h-9 w-9 items-center justify-center ${
              pathname.startsWith("/admin") ? "bg-slate-900 text-white" : "text-slate-600"
            }`}
          >
            <ShieldCheck size={18} aria-hidden="true" />
          </Link>
        )}
        <button
          type="button"
          disabled={isLoading}
          onClick={() => void handleAuthAction()}
          className={`${isAdmin ? "ml-1" : "ml-auto"} flex h-9 items-center gap-2 px-2 text-xs font-bold text-slate-600 disabled:text-slate-300`}
        >
          {user ? <LogOut size={17} aria-hidden="true" /> : <LogIn size={17} aria-hidden="true" />}
          {user ? "로그아웃" : "Google 로그인"}
        </button>
      </header>

      <header className="sticky top-0 z-40 hidden border-b border-slate-200 bg-white/95 backdrop-blur md:block">
        <div className="mx-auto flex h-16 max-w-6xl items-center px-6">
          <Link href="/" className="mr-8 font-extrabold text-slate-950">
            PKNU 생활도우미
          </Link>
          <nav className="flex h-full items-center gap-1" aria-label="주요 메뉴">
            {primaryLinks.map(({ href, label, icon: Icon }) => (
              <Link
                key={href}
                href={href}
                className={`flex h-10 items-center gap-2 px-3 text-sm font-semibold transition ${
                  isActive(pathname, href)
                    ? "bg-sky-50 text-sky-800"
                    : "text-slate-600 hover:bg-slate-50 hover:text-slate-950"
                }`}
              >
                <Icon size={17} aria-hidden="true" />
                {label}
              </Link>
            ))}
          </nav>
          <div className="ml-auto flex items-center gap-2">
            {isAdmin && (
              <Link
                href="/admin"
                className={`flex h-10 items-center gap-2 px-3 text-sm font-semibold transition ${
                  pathname.startsWith("/admin")
                    ? "bg-slate-900 text-white"
                    : "text-slate-600 hover:bg-slate-100"
                }`}
              >
                <ShieldCheck size={17} aria-hidden="true" />
                관리자
              </Link>
            )}
            <button
              type="button"
              disabled={isLoading}
              onClick={() => void handleAuthAction()}
              title={user?.email ?? "Google 계정으로 로그인"}
              className="flex h-10 items-center gap-2 border border-slate-300 px-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 disabled:text-slate-300"
            >
              {user ? <LogOut size={17} aria-hidden="true" /> : <LogIn size={17} aria-hidden="true" />}
              {user ? "로그아웃" : "Google 로그인"}
            </button>
          </div>
        </div>
      </header>

      <nav
        className="fixed inset-x-0 bottom-0 z-50 grid h-16 grid-cols-5 border-t border-slate-200 bg-white md:hidden"
        aria-label="모바일 주요 메뉴"
      >
        {primaryLinks.map(({ href, label, icon: Icon }) => (
          <Link
            key={href}
            href={href}
            className={`flex min-w-0 flex-col items-center justify-center gap-1 text-[11px] font-semibold ${
              isActive(pathname, href) ? "text-sky-700" : "text-slate-500"
            }`}
          >
            <Icon size={20} strokeWidth={isActive(pathname, href) ? 2.5 : 2} aria-hidden="true" />
            <span className="truncate">{label}</span>
          </Link>
        ))}
      </nav>
    </>
  );
}
