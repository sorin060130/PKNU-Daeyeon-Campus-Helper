import type { Facility } from "../../services/realtimeDatabaseExample";

type FacilityCardProps = {
  facility: Facility;
};

export function FacilityCard({ facility }: FacilityCardProps) {
  return (
    <article className="border border-slate-200 bg-white p-5 shadow-sm transition hover:border-sky-300 hover:shadow-md">
      <div className="flex items-start justify-between gap-4">
        <div className="min-w-0">
          <p className="mb-2 text-sm font-semibold text-sky-700">
            {facility.category || "종류 미등록"}
          </p>
          <h2 className="truncate text-lg font-bold text-slate-950">{facility.name}</h2>
        </div>
        <span
          aria-hidden="true"
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-sky-50 text-lg font-bold text-sky-700"
        >
          {facility.name?.charAt(0) || "시"}
        </span>
      </div>

      <dl className="mt-5 grid gap-3 border-t border-slate-100 pt-4 text-sm">
        <div className="grid grid-cols-[5rem_1fr] gap-3">
          <dt className="font-medium text-slate-500">건물명</dt>
          <dd className="text-slate-800">{facility.building || "정보 없음"}</dd>
        </div>
        <div className="grid grid-cols-[5rem_1fr] gap-3">
          <dt className="font-medium text-slate-500">운영시간</dt>
          <dd className="text-slate-800">{facility.operatingHours || "정보 없음"}</dd>
        </div>
      </dl>
    </article>
  );
}
