import { get, ref } from "firebase/database";

import { database } from "../lib/firebase";

export type Weekday =
  | "sunday"
  | "monday"
  | "tuesday"
  | "wednesday"
  | "thursday"
  | "friday"
  | "saturday";

export type Schedule = {
  id: string;
  classroomId: string;
  classroomName: string;
  building: string;
  day: Weekday;
  startTime: string;
  endTime: string;
};

export async function readSchedules(): Promise<Schedule[]> {
  const snapshot = await get(ref(database, "schedules"));

  if (!snapshot.exists()) {
    return [];
  }

  const schedules = snapshot.val() as Record<string, Omit<Schedule, "id">>;

  return Object.entries(schedules).map(([id, schedule]) => ({
    id,
    ...schedule,
  }));
}
