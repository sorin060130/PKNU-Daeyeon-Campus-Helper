"use client";

import { useEffect, useMemo, useState } from "react";

import {
  AvailableClassroomCard,
  type AvailableClassroom,
} from "../../components/classrooms/AvailableClassroomCard";
import {
  readSchedules,
  type Schedule,
  type Weekday,
} from "../../services/scheduleService";
import {
  subscribeToRoomUsage,
  type RoomUsage,
} from "../../services/roomUsageService";

const WEEKDAYS: Weekday[] = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
];

function timeToMinutes(time: string): number {
  const [hour = "0", minute = "0"] = time.split(":");
  return Number(hour) * 60 + Number(minute);
}

const WEEKDAY_LABELS: Record<Weekday, string> = {
  sunday: "일요일",
  monday: "월요일",
  tuesday: "화요일",
  wednesday: "수요일",
  thursday: "목요일",
  friday: "금요일",
  saturday: "토요일",
};

type CampusTime = {
  day: Weekday;
  time: string;
  label: string;
};

function getCampusTime(): CampusTime {
  const now = new Date();
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "Asia/Seoul",
    weekday: "short",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(now);
  const weekday = parts.find((part) => part.type === "weekday")?.value ?? "Sun";
  const hour = parts.find((part) => part.type === "hour")?.value ?? "00";
  const minute = parts.find((part) => part.type === "minute")?.value ?? "00";
  const dayIndex = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].indexOf(weekday);
  const day = WEEKDAYS[Math.max(dayIndex, 0)] ?? "sunday";

  return {
    day,
    time: `${hour}:${minute}`,
    label: `${WEEKDAY_LABELS[day]} ${hour}:${minute}`,
  };
}

function getAvailableClassrooms(
  schedules: Schedule[],
  campusTime: CampusTime,
): AvailableClassroom[] {
  const classrooms = new Map<string, Schedule[]>();
  const currentMinutes = timeToMinutes(campusTime.time);

  schedules.forEach((schedule) => {
    const key = schedule.classroomId || `${schedule.building}-${schedule.classroomName}`;
    classrooms.set(key, [...(classrooms.get(key) ?? []), schedule]);
  });

  return Array.from(classrooms.entries())
    .filter(([, classroomSchedules]) => {
      return !classroomSchedules.some(
        (schedule) =>
          schedule.day === campusTime.day &&
          timeToMinutes(schedule.startTime) <= currentMinutes &&
          currentMinutes < timeToMinutes(schedule.endTime),
      );
    })
    .map(([id, classroomSchedules]) => {
      const firstSchedule = classroomSchedules[0]!;
      const nextClass =
        classroomSchedules
          .filter(
            (schedule) =>
              schedule.day === campusTime.day &&
              timeToMinutes(schedule.startTime) > currentMinutes,
          )
          .sort((a, b) => timeToMinutes(a.startTime) - timeToMinutes(b.startTime))[0] ?? null;

      return {
        id,
        name: firstSchedule.classroomName,
        building: firstSchedule.building,
        nextClassStart: nextClass?.startTime ?? null,
      };
    })
    .sort((a, b) => {
      if (a.nextClassStart && b.nextClassStart) {
        return timeToMinutes(a.nextClassStart) - timeToMinutes(b.nextClassStart);
      }

      if (a.nextClassStart) return -1;
      if (b.nextClassStart) return 1;
      return (
        a.building.localeCompare(b.building, "ko-KR") ||
        a.name.localeCompare(b.name, "ko-KR")
      );
    });
}

export default function ClassroomsPage() {
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [roomUsage, setRoomUsage] = useState<Record<string, RoomUsage>>({});
  const [sessionId, setSessionId] = useState("");
  const [campusTime, setCampusTime] = useState<CampusTime>(() => getCampusTime());
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    const storageKey = "pknu-room-usage-session-id";
    const savedSessionId = window.localStorage.getItem(storageKey);
    const currentSessionId =
      savedSessionId ??
      (window.crypto.randomUUID
        ? window.crypto.randomUUID()
        : `${Date.now()}-${Math.random().toString(36).slice(2)}`);

    window.localStorage.setItem(storageKey, currentSessionId);
    setSessionId(currentSessionId);

    async function loadSchedules() {
      try {
        setSchedules(await readSchedules());
      } catch (error) {
        console.error("Failed to load schedules:", error);
        setErrorMessage("강의실 정보를 불러오지 못했습니다. 잠시 후 다시 시도해 주세요.");
      } finally {
        setIsLoading(false);
      }
    }

    void loadSchedules();

    const unsubscribeRoomUsage = subscribeToRoomUsage(setRoomUsage, (error) => {
      console.error("Failed to subscribe to room usage:", error);
    });
    const timer = window.setInterval(() => setCampusTime(getCampusTime()), 60_000);
    return () => {
      unsubscribeRoomUsage();
      window.clearInterval(timer);
    };
  }, []);

  const availableClassrooms = useMemo(
    () => getAvailableClassrooms(schedules, campusTime),
    [schedules, campusTime],
  );

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-7 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <header className="mb-6">
          <p className="mb-2 text-sm font-semibold text-emerald-700">대연캠퍼스</p>
          <h1 className="text-2xl font-bold text-slate-950 sm:text-3xl">빈 강의실 조회</h1>
          <p className="mt-2 text-sm text-slate-600">
            한국 시간 기준 <strong className="font-semibold text-slate-900">{campusTime.label}</strong>
          </p>
        </header>

        {!isLoading && !errorMessage && (
          <div className="mb-5 flex items-center justify-between border-y border-slate-200 py-3">
            <p className="text-sm text-slate-600">현재 수업 중인 강의실 제외</p>
            <p className="text-sm font-bold text-emerald-700">
              {availableClassrooms.length}개 사용 가능
            </p>
          </div>
        )}

        {isLoading && (
          <div className="border border-slate-200 bg-white px-5 py-14 text-center text-sm text-slate-600">
            현재 사용 가능한 강의실을 확인하는 중입니다.
          </div>
        )}

        {errorMessage && (
          <div
            role="alert"
            className="border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700"
          >
            {errorMessage}
          </div>
        )}

        {!isLoading && !errorMessage && availableClassrooms.length === 0 && (
          <div className="border border-slate-200 bg-white px-5 py-14 text-center">
            <p className="font-semibold text-slate-900">현재 사용 가능한 강의실이 없습니다.</p>
            <p className="mt-1 text-sm text-slate-500">잠시 후 다시 확인해 주세요.</p>
          </div>
        )}

        {!isLoading && !errorMessage && availableClassrooms.length > 0 && (
          <section
            aria-label="현재 사용 가능한 강의실"
            className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
          >
            {availableClassrooms.map((classroom) => (
              <AvailableClassroomCard
                key={classroom.id}
                classroom={classroom}
                roomUsage={roomUsage[classroom.id]}
                sessionId={sessionId}
              />
            ))}
          </section>
        )}
      </div>
    </main>
  );
}
