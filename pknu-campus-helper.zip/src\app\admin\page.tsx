"use client";

import { useEffect, useMemo, useState } from "react";
import { useRouter } from "next/navigation";

import { useAuth } from "../../components/auth/AuthProvider";
import {
  approveSubmission,
  rejectSubmission,
  subscribeToSubmissions,
  type ScheduleSubmission,
} from "../../services/submissionService";

const DAY_LABELS: Record<string, string> = {
  monday: "월요일",
  tuesday: "화요일",
  wednesday: "수요일",
  thursday: "목요일",
  friday: "금요일",
  saturday: "토요일",
  sunday: "일요일",
};

export default function AdminPage() {
  const router = useRouter();
  const { user, isLoading: isAuthLoading, isAdmin } = useAuth();
  const [submissions, setSubmissions] = useState<ScheduleSubmission[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [processingId, setProcessingId] = useState("");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    if (isAuthLoading) {
      return;
    }

    if (!user || !isAdmin) {
      router.replace("/");
    }
  }, [isAdmin, isAuthLoading, router, user]);

  useEffect(() => {
    if (isAuthLoading || !isAdmin) {
      return;
    }

    return subscribeToSubmissions(
      (data) => {
        setSubmissions(data);
        setIsLoading(false);
      },
      (error) => {
        console.error("Failed to load submissions:", error);
        setErrorMessage("수정 신청 목록을 불러오지 못했습니다.");
        setIsLoading(false);
      },
    );
  }, [isAdmin, isAuthLoading]);

  const pendingSubmissions = useMemo(
    () => submissions.filter((submission) => submission.status === "pending"),
    [submissions],
  );

  async function review(
    submission: ScheduleSubmission,
    action: "approve" | "reject",
  ) {
    setProcessingId(submission.id);
    setErrorMessage("");

    try {
      if (action === "approve") {
        await approveSubmission(submission);
      } else {
        await rejectSubmission(submission.id);
      }
    } catch (error) {
      console.error("Failed to review submission:", error);
      setErrorMessage("처리하지 못했습니다. Firebase 권한과 연결 상태를 확인해 주세요.");
    } finally {
      setProcessingId("");
    }
  }

  if (isAuthLoading || !isAdmin) {
    return (
      <main className="page-shell">
        <div className="content-wrap">
          <div className="empty-panel">
            {isAuthLoading ? "관리자 권한을 확인하는 중입니다." : "홈으로 이동하는 중입니다."}
          </div>
        </div>
      </main>
    );
  }

  return (
    <main className="page-shell">
      <div className="content-wrap">
        <header className="mb-7">
          <p className="eyebrow">관리자</p>
          <h1 className="page-title">시간표 수정 신청 관리</h1>
          <p className="page-description">승인 대기 중인 신청을 검토하고 시간표에 반영합니다.</p>
        </header>

        {errorMessage && <p className="status-error">{errorMessage}</p>}

        {!isLoading && (
          <div className="mb-5 flex items-center justify-between border-y border-slate-200 py-3">
            <span className="text-sm text-slate-600">승인 대기</span>
            <strong className="text-sm text-sky-700">{pendingSubmissions.length}건</strong>
          </div>
        )}

        {isLoading && <div className="empty-panel">신청 목록을 불러오는 중입니다.</div>}

        {!isLoading && pendingSubmissions.length === 0 && (
          <div className="empty-panel">
            <strong className="block text-slate-900">승인 대기 중인 신청이 없습니다.</strong>
            <span className="mt-1 block">새로운 신청이 접수되면 여기에 표시됩니다.</span>
          </div>
        )}

        <section className="grid gap-4 lg:grid-cols-2" aria-label="승인 대기 신청 목록">
          {pendingSubmissions.map((submission) => {
            const isProcessing = processingId === submission.id;

            return (
              <article key={submission.id} className="card p-5">
                <div className="flex items-start justify-between gap-4">
                  <div>
                    <p className="text-xs font-bold text-amber-700">PENDING</p>
                    <h2 className="mt-1 text-lg font-bold text-slate-950">
                      {submission.classroomName}
                    </h2>
                  </div>
                  <time className="text-xs text-slate-500">
                    {new Date(submission.createdAt).toLocaleDateString("ko-KR")}
                  </time>
                </div>

                <dl className="mt-5 grid gap-3 border-t border-slate-100 pt-4 text-sm">
                  <div className="grid grid-cols-[5rem_1fr] gap-3">
                    <dt className="text-slate-500">변경 시간</dt>
                    <dd className="font-medium text-slate-900">
                      {DAY_LABELS[submission.day]} {submission.startTime} - {submission.endTime}
                    </dd>
                  </div>
                  <div className="grid grid-cols-[5rem_1fr] gap-3">
                    <dt className="text-slate-500">수정 사유</dt>
                    <dd className="whitespace-pre-wrap text-slate-800">{submission.reason}</dd>
                  </div>
                </dl>

                <div className="mt-5 grid grid-cols-2 gap-3">
                  <button
                    type="button"
                    disabled={isProcessing}
                    onClick={() => void review(submission, "reject")}
                    className="button-secondary"
                  >
                    반려
                  </button>
                  <button
                    type="button"
                    disabled={isProcessing}
                    onClick={() => void review(submission, "approve")}
                    className="button-primary"
                  >
                    {isProcessing ? "처리 중..." : "승인"}
                  </button>
                </div>
              </article>
            );
          })}
        </section>
      </div>
    </main>
  );
}
