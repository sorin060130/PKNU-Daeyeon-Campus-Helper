import { get, push, ref, set, update } from "firebase/database";

import { database } from "../lib/firebase";

export type Facility = {
  id: string;
  name: string;
  category: string;
  building: string;
  operatingHours: string;
  floor?: string;
  updatedAt: number;
};

// Reads every facility once.
export async function readFacilities(): Promise<Facility[]> {
  const snapshot = await get(ref(database, "facilities"));

  if (!snapshot.exists()) {
    return [];
  }

  const facilities = snapshot.val() as Record<string, Omit<Facility, "id">>;

  return Object.entries(facilities).map(([id, facility]) => ({
    id,
    ...facility,
  }));
}

// Creates a facility with a Firebase-generated ID.
export async function createFacility(
  facility: Omit<Facility, "id" | "updatedAt">,
): Promise<string> {
  const facilityRef = push(ref(database, "facilities"));

  await set(facilityRef, {
    ...facility,
    updatedAt: Date.now(),
  });

  if (!facilityRef.key) {
    throw new Error("Firebase did not generate a facility ID.");
  }

  return facilityRef.key;
}

// Updates selected fields of an existing facility.
export async function updateFacility(
  facilityId: string,
  changes: Partial<Omit<Facility, "id" | "updatedAt">>,
): Promise<void> {
  await update(ref(database, `facilities/${facilityId}`), {
    ...changes,
    updatedAt: Date.now(),
  });
}
