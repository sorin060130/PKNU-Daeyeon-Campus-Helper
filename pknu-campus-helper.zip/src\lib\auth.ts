import { GoogleAuthProvider, signInWithPopup, signOut } from "firebase/auth";

import { auth } from "./firebase";

export const ADMIN_EMAILS = ["seongil@pukyong.ac.kr"];

export function isAdminEmail(email: string | null | undefined): boolean {
  return Boolean(email && ADMIN_EMAILS.includes(email.toLowerCase()));
}

export async function signInWithGoogle(): Promise<void> {
  const provider = new GoogleAuthProvider();
  provider.setCustomParameters({ prompt: "select_account" });
  await signInWithPopup(auth, provider);
}

export async function signOutUser(): Promise<void> {
  await signOut(auth);
}
