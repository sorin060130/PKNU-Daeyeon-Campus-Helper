"use client";

import { type FormEvent, useState } from "react";

import type { Weekday } from "../../services/scheduleService";
import { createScheduleSubmission } from "../../services/submissionService";

const WEEKDAY_OPTIONS: Array<{ value: Weekday; label: string }> = [
  { value: "monday", label: "월요일" },
  { value: "tuesday", label: "화요일" },
  { value: "wednesday", label: "수요일" },
  { value: "thursday", label: "목요일" },
  { value: "friday", label: "금요일" },
  { value: "saturday", label: "토요일" },
  { value: "sunday", label: "일요일" },
];

const inputClassName =
  "mt-2 h-12 w-full border border-slate-300 bg-white px-3 text-base text-slate-950 outline-none transition focus:border-sky-600 focus:ring-2 focus:ring-sky-100";

export default function EditRequestPage() {
  const [classroomName, setClassroomName] = useState("");
  const [day, setDay] = useState<Weekday>("monday");
  const [startTime, setStartTime] = useState("");
  const [endTime, setEndTime] = useState("");
  const [reason, setReason] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setErrorMessage("");
    setIsSubmitted(false);

    if (startTime >= endTime) {
      setErrorMessage("종료시간은 시작시간보다 늦어야 합니다.");
      return;
    }

    setIsSubmitting(true);

    try {
      await createScheduleSubmission({
        classroomName: classroomName.trim(),
        day,
        startTime,
        endTime,
        reason: reason.trim(),
      });

      setClassroomName("");
      setDay("monday");
      setStartTime("");
      setEndTime("");
      setReason("");
      setIsSubmitted(true);
    } catch (error) {
      console.error("Failed to submit schedule correction:", error);
      setErrorMessage("수정 신청을 저장하지 못했습니다. 잠시 후 다시 시도해 주세요.");
    } finally {
      setIsSubmitting(false);
    }
  }

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-7 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-2xl">
        <header className="mb-6">
          <p className="mb-2 text-sm font-semibold text-sky-700">대연캠퍼스</p>
          <h1 className="text-2xl font-bold text-slate-950 sm:text-3xl">
            강의실 시간표 수정 신청
          </h1>
          <p className="mt-2 text-sm text-slate-600">
            실제 시간표와 다른 수업 정보를 알려주세요.
          </p>
        </header>

        <form
          onSubmit={handleSubmit}
          className="border border-slate-200 bg-white p-5 shadow-sm sm:p-7"
        >
          <div>
            <label htmlFor="classroom-name" className="text-sm font-semibold text-slate-800">
              강의실명
            </label>
            <input
              id="classroom-name"
              type="text"
              required
              value={classroomName}
              onChange={(event) => setClassroomName(event.target.value)}
              placeholder="예: 향파관 101호"
              className={inputClassName}
            />
          </div>

          <div className="mt-5">
            <label htmlFor="weekday" className="text-sm font-semibold text-slate-800">
              요일
            </label>
            <select
              id="weekday"
              required
              value={day}
              onChange={(event) => setDay(event.target.value as Weekday)}
              className={inputClassName}
            >
              {WEEKDAY_OPTIONS.map((option) => (
                <option key={option.value} value={option.value}>
                  {option.label}
                </option>
              ))}
            </select>
          </div>

          <div className="mt-5 grid grid-cols-2 gap-3 sm:gap-5">
            <div>
              <label htmlFor="start-time" className="text-sm font-semibold text-slate-800">
                시작시간
              </label>
              <input
                id="start-time"
                type="time"
                required
                value={startTime}
                onChange={(event) => setStartTime(event.target.value)}
                className={inputClassName}
              />
            </div>
            <div>
              <label htmlFor="end-time" className="text-sm font-semibold text-slate-800">
                종료시간
              </label>
              <input
                id="end-time"
                type="time"
                required
                value={endTime}
                onChange={(event) => setEndTime(event.target.value)}
                className={inputClassName}
              />
            </div>
          </div>

          <div className="mt-5">
            <label htmlFor="reason" className="text-sm font-semibold text-slate-800">
              수정사유
            </label>
            <textarea
              id="reason"
              required
              rows={5}
              value={reason}
              onChange={(event) => setReason(event.target.value)}
              placeholder="수정이 필요한 내용을 자세히 입력해 주세요."
              className="mt-2 w-full resize-y border border-slate-300 bg-white px-3 py-3 text-base text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-sky-600 focus:ring-2 focus:ring-sky-100"
            />
          </div>

          {errorMessage && (
            <p role="alert" className="mt-5 bg-red-50 px-3 py-3 text-sm font-medium text-red-700">
              {errorMessage}
            </p>
          )}

          {isSubmitted && (
            <p role="status" className="mt-5 bg-emerald-50 px-3 py-3 text-sm font-medium text-emerald-800">
              수정 신청이 접수되었습니다.
            </p>
          )}

          <button
            type="submit"
            disabled={isSubmitting}
            className="mt-6 h-12 w-full bg-sky-700 px-4 text-base font-bold text-white transition hover:bg-sky-800 disabled:cursor-not-allowed disabled:bg-slate-300"
          >
            {isSubmitting ? "신청 중..." : "수정 신청 제출"}
          </button>
        </form>
      </div>
    </main>
  );
}
