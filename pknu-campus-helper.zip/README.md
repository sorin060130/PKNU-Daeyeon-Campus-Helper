# PKNU 생활도우미

부경대학교 대연캠퍼스 시설과 빈 강의실 정보를 제공하는 반응형 웹앱입니다.

## 시작하기

```bash
npm install
copy .env.local.example .env.local
npm run dev
```

`.env.local`에 Firebase 프로젝트 값을 입력한 뒤 실행합니다.

`.env.local.example`은 예시 파일입니다. 프로젝트 루트에 실제 `.env.local` 파일을 만들고
Firebase Console의 프로젝트 설정에 표시되는 웹 앱 구성 값을 입력해야 합니다.
환경변수를 변경한 뒤에는 개발 서버를 다시 시작합니다.

## 주요 경로

- `/` 홈
- `/facilities` 시설 조회
- `/classrooms` 빈 강의실 조회 및 이용 상태 공유
- `/edit-request` 강의실 시간표 수정 신청
- `/favorites` 즐겨찾기
- `/admin` 관리자 전용 수정 신청 승인 및 반려

## Firebase 데이터

- `facilities`
- `schedules`
- `roomUsage`
- `submissions`

## Google 로그인과 관리자

Firebase Console에서 Authentication의 Google 로그인 제공업체를 활성화해야 합니다.
일반 조회 기능은 로그인 없이 사용할 수 있습니다.

관리자 이메일은 `src/lib/auth.ts`의 `ADMIN_EMAILS` 배열에서 관리합니다.
관리자 페이지는 로그인한 이메일이 해당 배열에 포함된 경우에만 접근할 수 있습니다.

클라이언트 화면의 관리자 접근 제한과 별개로 실제 배포 전 Realtime Database 보안 규칙에서도 관리자 쓰기 권한을 제한해야 합니다.
