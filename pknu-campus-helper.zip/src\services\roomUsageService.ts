import { onValue, ref, runTransaction, type Unsubscribe } from "firebase/database";

import { database } from "../lib/firebase";

export type RoomUsage = {
  classroomId: string;
  sessionId: string;
  startedAt: number;
};

function roomUsageKey(classroomId: string): string {
  return encodeURIComponent(classroomId).replace(/\./g, "%2E");
}

export function subscribeToRoomUsage(
  onChange: (usageByClassroom: Record<string, RoomUsage>) => void,
  onError: (error: Error) => void,
): Unsubscribe {
  return onValue(
    ref(database, "roomUsage"),
    (snapshot) => {
      if (!snapshot.exists()) {
        onChange({});
        return;
      }

      const usageRecords = snapshot.val() as Record<string, RoomUsage>;
      const usageByClassroom = Object.values(usageRecords).reduce<Record<string, RoomUsage>>(
        (result, usage) => {
          result[usage.classroomId] = usage;
          return result;
        },
        {},
      );

      onChange(usageByClassroom);
    },
    onError,
  );
}

export async function startRoomUsage(
  classroomId: string,
  sessionId: string,
): Promise<boolean> {
  const result = await runTransaction(
    ref(database, `roomUsage/${roomUsageKey(classroomId)}`),
    (currentUsage: RoomUsage | null) => {
      if (currentUsage) {
        return;
      }

      return {
        classroomId,
        sessionId,
        startedAt: Date.now(),
      };
    },
  );

  return result.committed;
}

export async function endRoomUsage(
  classroomId: string,
  sessionId: string,
): Promise<boolean> {
  const result = await runTransaction(
    ref(database, `roomUsage/${roomUsageKey(classroomId)}`),
    (currentUsage: RoomUsage | null) => {
      if (!currentUsage || currentUsage.sessionId !== sessionId) {
        return;
      }

      return null;
    },
  );

  return result.committed;
}
