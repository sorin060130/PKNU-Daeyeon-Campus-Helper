"use client";

import { useEffect, useMemo, useState } from "react";

import { FacilityCard } from "../../components/facilities/FacilityCard";
import {
  readFacilities,
  type Facility,
} from "../../services/realtimeDatabaseExample";

export default function FacilitiesPage() {
  const [facilities, setFacilities] = useState<Facility[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [isLoading, setIsLoading] = useState(true);
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    async function loadFacilities() {
      try {
        const data = await readFacilities();
        setFacilities(data);
      } catch (error) {
        console.error("Failed to load facilities:", error);
        setErrorMessage("시설 정보를 불러오지 못했습니다. 잠시 후 다시 시도해 주세요.");
      } finally {
        setIsLoading(false);
      }
    }

    void loadFacilities();
  }, []);

  const filteredFacilities = useMemo(() => {
    const keyword = searchTerm.trim().toLocaleLowerCase("ko-KR");

    if (!keyword) {
      return facilities;
    }

    return facilities.filter((facility) =>
      facility.name.toLocaleLowerCase("ko-KR").includes(keyword),
    );
  }, [facilities, searchTerm]);

  return (
    <main className="min-h-screen bg-slate-50 px-4 py-8 sm:px-6 lg:px-8">
      <div className="mx-auto max-w-6xl">
        <header className="mb-7">
          <p className="mb-2 text-sm font-semibold text-sky-700">대연캠퍼스</p>
          <h1 className="text-2xl font-bold text-slate-950 sm:text-3xl">시설 조회</h1>
          <p className="mt-2 text-sm text-slate-600">
            캠퍼스 내 편의시설의 위치와 운영시간을 확인하세요.
          </p>
        </header>

        <div className="mb-6">
          <label htmlFor="facility-search" className="sr-only">
            시설명 검색
          </label>
          <input
            id="facility-search"
            type="search"
            value={searchTerm}
            onChange={(event) => setSearchTerm(event.target.value)}
            placeholder="시설명을 검색하세요"
            className="h-12 w-full border border-slate-300 bg-white px-4 text-base text-slate-950 outline-none transition placeholder:text-slate-400 focus:border-sky-600 focus:ring-2 focus:ring-sky-100"
          />
        </div>

        {!isLoading && !errorMessage && (
          <p className="mb-4 text-sm text-slate-600">
            총 <strong className="font-semibold text-slate-950">{filteredFacilities.length}</strong>개
          </p>
        )}

        {isLoading && (
          <div className="border border-slate-200 bg-white px-5 py-14 text-center text-sm text-slate-600">
            시설 정보를 불러오는 중입니다.
          </div>
        )}

        {errorMessage && (
          <div
            role="alert"
            className="border border-red-200 bg-red-50 px-5 py-4 text-sm text-red-700"
          >
            {errorMessage}
          </div>
        )}

        {!isLoading && !errorMessage && filteredFacilities.length === 0 && (
          <div className="border border-slate-200 bg-white px-5 py-14 text-center">
            <p className="font-semibold text-slate-900">검색 결과가 없습니다.</p>
            <p className="mt-1 text-sm text-slate-500">다른 시설명으로 검색해 보세요.</p>
          </div>
        )}

        {!isLoading && !errorMessage && filteredFacilities.length > 0 && (
          <section
            aria-label="시설 목록"
            className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3"
          >
            {filteredFacilities.map((facility) => (
              <FacilityCard key={facility.id} facility={facility} />
            ))}
          </section>
        )}
      </div>
    </main>
  );
}
