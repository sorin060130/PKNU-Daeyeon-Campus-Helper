import { Heart } from "lucide-react";
import Link from "next/link";

export default function FavoritesPage() {
  return (
    <main className="page-shell">
      <div className="content-wrap">
        <header className="mb-7">
          <p className="eyebrow">대연캠퍼스</p>
          <h1 className="page-title">즐겨찾기</h1>
          <p className="page-description">자주 확인하는 시설과 강의실을 모아볼 수 있습니다.</p>
        </header>

        <div className="empty-panel">
          <Heart className="mx-auto text-slate-400" size={30} aria-hidden="true" />
          <strong className="mt-4 block text-slate-900">아직 즐겨찾기가 없습니다.</strong>
          <Link
            href="/facilities"
            className="mt-5 inline-flex h-11 items-center bg-sky-700 px-5 text-sm font-bold text-white hover:bg-sky-800"
          >
            시설 둘러보기
          </Link>
        </div>
      </div>
    </main>
  );
}
